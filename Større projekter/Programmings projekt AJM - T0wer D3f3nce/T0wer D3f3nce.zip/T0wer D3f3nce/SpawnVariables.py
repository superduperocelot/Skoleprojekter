lastEnemySpawnTime = 0
currentEnemySpawn = 0
EnemySpawnDelay = 0
roundRunning = False
currentRound = 0



Health = 100
Money = 450
