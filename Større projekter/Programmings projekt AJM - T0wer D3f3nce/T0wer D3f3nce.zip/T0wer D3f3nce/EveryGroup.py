import pygame
enemies = pygame.sprite.Group()
towers = pygame.sprite.Group()
