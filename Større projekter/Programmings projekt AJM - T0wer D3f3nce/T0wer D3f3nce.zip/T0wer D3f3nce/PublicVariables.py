lastEnemySpawnTime = 0
currentEnemySpawn = 0
enemySpawnDelay = 0
roundRunning = False
currentRound = 0

health = 100
money = 450

victory = False